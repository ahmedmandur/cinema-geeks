import api from './api';
import storage from './storage';

export {
	api,
	storage
};
