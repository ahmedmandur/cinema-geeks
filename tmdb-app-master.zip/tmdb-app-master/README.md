# The Movie Database App
A ReactJS project.

![](https://github.com/maqsudkarimov/tmdb-app/blob/master/docs/demo.jpg)
## Demo
[TMDB ReactJS App](https://maqsudkarimov.github.io/tmdb-app)
## Build Setup
``` bash
# install dependencies
npm install

# serve with hot reload at localhost:3000
npm start

# build for production with minification
npm run build
```
